/*****************************************************************************
// File Name :         Mine.cs
// Author :            Rudy Wolfer
// Creation Date :     October 6th, 2022
//
// Brief Description : Script controlling Mine buildings.
*****************************************************************************/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mine : Building
{
    
}
