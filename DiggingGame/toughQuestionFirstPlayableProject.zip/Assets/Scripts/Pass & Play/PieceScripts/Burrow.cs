/*****************************************************************************
// File Name :         Mine.cs
// Author :            Rudy Wolfer
// Creation Date :     October 6th, 2022
//
// Brief Description : Script controlling Burrow buildings.
*****************************************************************************/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Burrow : Building
{
    
}
