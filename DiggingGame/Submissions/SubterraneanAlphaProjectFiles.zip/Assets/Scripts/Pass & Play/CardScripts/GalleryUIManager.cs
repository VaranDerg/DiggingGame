using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GalleryUIManager : MonoBehaviour
{
    public CardGallery cardGallery;
    public GameObject cardSlots;
}
