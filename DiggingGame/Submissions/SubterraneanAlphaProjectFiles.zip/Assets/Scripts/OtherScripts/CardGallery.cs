using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CardGallery : MonoBehaviour
{
    public List<GameObject> cards = new List<GameObject>();
}
